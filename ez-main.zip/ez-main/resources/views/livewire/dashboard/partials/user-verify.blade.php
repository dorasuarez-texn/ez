<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        @include('livewire.dashboard.partials.verify-wrapper')
    </div>
</div>